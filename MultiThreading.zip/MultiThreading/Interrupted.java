package thread;

import java.util.Random;

public class Interrupted {

	public static void main(String[] args) throws InterruptedException {

		Thread t1 = new Thread(() -> {
			Random number = new Random();
			for (int i = 0; i < 10000; i++) {
				System.out.println(i);
				if (Thread.currentThread().isInterrupted()) {
					System.out.println("Interrupted");
					break;
				}
			}
		});
		t1.start();
		Thread.sleep(10);
		t1.interrupt();
		t1.join();
	}

}
