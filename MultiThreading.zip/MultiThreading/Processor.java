package waitNotify;

import java.util.Scanner;

public class Processor {

	public void producer() throws InterruptedException {
		synchronized (this) {
			System.out.println("Producer thread starting....");
			// Thread.sleep(2000);
			wait();
			System.out.println("Producer thread completed...");
		}

	}

	public void consumer() throws InterruptedException {

		Scanner s = new Scanner(System.in);

		synchronized (this) {
			System.out.println("Consumer Thread is starting waiting for return key enter.....");
			s.nextLine();
			System.out.println("R...");
			notify();
			Thread.sleep(5000);

		}

	}
}
